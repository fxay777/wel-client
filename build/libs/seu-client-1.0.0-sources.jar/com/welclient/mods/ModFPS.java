package com.seuclient.mods;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;

public class ModFPS extends Gui {
    private final Minecraft mc = Minecraft.func_71410_x();
    
    public void render(int x, int y) {
        int fps = Minecraft.func_175610_ah();
        String textoFPS = "FPS: " + fps;
        
        // Código de cor baseado no FPS
        int cor;
        if (fps >= 60) {
            cor = 0xFF00FF00; // Verde
        } else if (fps >= 30) {
            cor = 0xFFFFFF00; // Amarelo
        } else {
            cor = 0xFFFF0000; // Vermelho
        }
        
        mc.field_71466_p.func_175063_a(textoFPS, x, y, cor);
    }
}