package com.seuclient.mods;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.EnumFacing;

public class ModDirecao extends Gui {
    private final Minecraft mc = Minecraft.func_71410_x();
    
    public void render(int x, int y) {
        if (mc.field_71439_g == null) return;
        
        EnumFacing direcao = mc.field_71439_g.func_174811_aO();
        String textoDirecao;
        
        switch (direcao) {
            case NORTH:
                textoDirecao = "Norte (Z-)";
                break;
            case SOUTH:
                textoDirecao = "Sul (Z+)";
                break;
            case EAST:
                textoDirecao = "Leste (X+)";
                break;
            case WEST:
                textoDirecao = "Oeste (X-)";
                break;
            default:
                textoDirecao = "Desconhecida";
        }
        
        mc.field_71466_p.func_175063_a("Direção: " + textoDirecao, x, y, 0xFFFFFFFF);
    }
}