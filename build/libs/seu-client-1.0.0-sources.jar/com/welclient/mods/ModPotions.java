package com.seuclient.mods;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.potion.PotionEffect;
import java.util.Collection;

public class ModPotions extends Gui {
    private final Minecraft mc = Minecraft.func_71410_x();
    
    public void render(int x, int y) {
        if (mc.field_71439_g == null) return;
        
        Collection<PotionEffect> potions = mc.field_71439_g.func_70651_bq();
        
        if (potions.isEmpty()) return;
        
        int yOffset = y;
        for (PotionEffect potion : potions) {
            String nomePotion = potion.func_76453_d();
            int duracao = potion.func_76459_b() / 20; // Converter para segundos
            int nivel = potion.func_76458_c() + 1;
            
            String texto = String.format("%s %s (%ds)", nomePotion, nivel, duracao);
            
            mc.field_71466_p.func_175063_a(texto, x, yOffset, 0xFFFFFFFF);
            yOffset += 10;
        }
    }
}