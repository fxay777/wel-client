package com.seuclient.mods;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.network.NetworkPlayerInfo;

public class ModPing extends Gui {
    private final Minecraft mc = Minecraft.func_71410_x();
    
    public void render(int x, int y) {
        if (mc.field_71439_g == null || mc.func_147114_u() == null) return;
        
        NetworkPlayerInfo info = mc.func_147114_u().func_175102_a(mc.field_71439_g.func_110124_au());
        
        if (info != null) {
            int ping = info.func_178853_c();
            String pingText = "Ping: " + ping + "ms";
            
            int cor;
            if (ping < 50) {
                cor = 0xFF00FF00; // Verde - Excelente
            } else if (ping < 100) {
                cor = 0xFFFFFF00; // Amarelo - Bom
            } else if (ping < 200) {
                cor = 0xFFFF8800; // Laranja - Médio
            } else {
                cor = 0xFFFF0000; // Vermelho - Ruim
            }
            
            mc.field_71466_p.func_175063_a(pingText, x, y, cor);
        }
    }
}