package com.seuclient.mods;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import java.text.DecimalFormat;

public class ModCoordenadas extends Gui {
    private final Minecraft mc = Minecraft.func_71410_x();
    
    public void render(int x, int y) {
        if (mc.field_71439_g == null) return;
        
        DecimalFormat df = new DecimalFormat("#.#");
        String coords = String.format("XYZ: %s, %s, %s", 
            df.format(mc.field_71439_g.field_70165_t),
            df.format(mc.field_71439_g.field_70163_u),
            df.format(mc.field_71439_g.field_70161_v));
        
        mc.field_71466_p.func_175063_a(coords, x, y, 0xFFFFFFFF);
    }
}