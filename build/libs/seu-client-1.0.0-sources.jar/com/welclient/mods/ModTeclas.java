package com.seuclient.mods;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class ModTeclas extends Gui {
    private final Minecraft mc = Minecraft.func_71410_x();
    private static final int LARGURA = 80;
    private static final int ALTURA = 60;
    
    public void render(int x, int y) {
        // Fundo
        Gui.func_73734_a(x, y, x + LARGURA, y + ALTURA, 0x80000000);
        
        // Tecla W
        desenharTecla(x + 30, y, Keyboard.getKeyName(mc.field_71474_y.field_74351_w.func_151463_i()), 
                teclaPressionada(mc.field_71474_y.field_74351_w));
        
        // Tecla A
        desenharTecla(x, y + 20, Keyboard.getKeyName(mc.field_71474_y.field_74370_x.func_151463_i()), 
                teclaPressionada(mc.field_71474_y.field_74370_x));
        
        // Tecla S
        desenharTecla(x + 30, y + 20, Keyboard.getKeyName(mc.field_71474_y.field_74368_y.func_151463_i()), 
                teclaPressionada(mc.field_71474_y.field_74368_y));
        
        // Tecla D
        desenharTecla(x + 60, y + 20, Keyboard.getKeyName(mc.field_71474_y.field_74366_z.func_151463_i()), 
                teclaPressionada(mc.field_71474_y.field_74366_z));
        
        // Tecla de Pular
        desenharTecla(x + 30, y + 40, "Pular", teclaPressionada(mc.field_71474_y.field_74314_A));
        
        // Tecla de Correr
        desenharTecla(x, y + 40, "Correr", teclaPressionada(mc.field_71474_y.field_151444_V));
    }
    
    private void desenharTecla(int x, int y, String tecla, boolean pressionada) {
        int cor = pressionada ? 0xFFFFFFFF : 0xFF888888;
        Gui.func_73734_a(x, y, x + 18, y + 18, cor);
        Gui.func_73734_a(x + 1, y + 1, x + 17, y + 17, 0xFF000000);
        
        mc.field_71466_p.func_78276_b(tecla, x + 5, y + 5, pressionada ? 0xFFFF5555 : 0xFFFFFFFF);
    }
    
    private boolean teclaPressionada(KeyBinding keyBinding) {
        return Keyboard.isKeyDown(keyBinding.func_151463_i());
    }
}