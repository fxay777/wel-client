package com.seuclient.mods;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumChatFormatting;

public class ModStatusArmadura extends Gui {
    private final Minecraft mc = Minecraft.func_71410_x();
    
    public void render(int x, int y) {
        if (mc.field_71439_g == null) return;
        
        ItemStack[] armadura = mc.field_71439_g.field_71071_by.field_70460_b;
        
        // Renderizar peças da armadura (botas ao capacete)
        for (int i = 0; i < armadura.length; i++) {
            ItemStack peca = armadura[i];
            
            if (peca != null) {
                int yOffset = y + (i * 16);
                
                // Desenhar ícone da armadura
                Gui.func_73734_a(x, yOffset, x + 14, yOffset + 14, 0x80000000);
                
                // Desenhar durabilidade
                int danoMaximo = peca.func_77958_k();
                int danoAtual = peca.func_77952_i();
                int durabilidade = danoMaximo - danoAtual;
                
                String textoDurabilidade;
                
                if (durabilidade > danoMaximo * 0.6) {
                    textoDurabilidade = EnumChatFormatting.GREEN + String.valueOf(durabilidade);
                } else if (durabilidade > danoMaximo * 0.3) {
                    textoDurabilidade = EnumChatFormatting.YELLOW + String.valueOf(durabilidade);
                } else {
                    textoDurabilidade = EnumChatFormatting.RED + String.valueOf(durabilidade);
                }
                
                mc.field_71466_p.func_78276_b(textoDurabilidade, x + 16, yOffset + 3, 0xFFFFFFFF);
            }
        }
    }
}