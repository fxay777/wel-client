package com.seuclient.mods;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.MovingObjectPosition;

public class ModDisplayAlcance extends Gui {
    private final Minecraft mc = Minecraft.func_71410_x();

    public void render(int x, int y) {
        MovingObjectPosition alvo = mc.field_71476_x;
        String texto = "Alcance: -";

        if (alvo != null && mc.field_71439_g != null) {
            double alcance = mc.field_71439_g.func_70011_f(alvo.field_72307_f.field_72450_a, alvo.field_72307_f.field_72448_b, alvo.field_72307_f.field_72449_c);
            texto = String.format("Alcance: %.1f", alcance);
        }

        mc.field_71466_p.func_175063_a(texto, x, y, 0xFFFFFFFF);
    }
}
