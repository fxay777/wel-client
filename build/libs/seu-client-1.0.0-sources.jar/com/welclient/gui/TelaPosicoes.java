package com.seuclient.gui;

import com.seuclient.core.Config;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class TelaPosicoes extends GuiScreen {
    @Override
    public void func_73866_w_() {
        field_146292_n.add(new GuiButton(0, field_146294_l / 2 - 100, field_146295_m / 2 - 30, 200, 20, "Teclas: " + Config.posXTeclas + ", " + Config.posYTeclas));
        field_146292_n.add(new GuiButton(1, field_146294_l / 2 - 100, field_146295_m / 2, 200, 20, "FPS: " + Config.posXFPS + ", " + Config.posYFPS));
        field_146292_n.add(new GuiButton(2, field_146294_l / 2 - 100, field_146295_m / 2 + 30, 200, 20, "Voltar"));
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == 0) {
            Config.posXTeclas = Config.posXTeclas == 10 ? 20 : 10;
        } else if (button.field_146127_k == 1) {
            Config.posXFPS = Config.posXFPS == 10 ? 20 : 10;
        } else if (button.field_146127_k == 2) {
            field_146297_k.func_147108_a(new TelaConfiguracao());
            return;
        }
        func_73866_w_();
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        func_73732_a(field_146289_q, "Posicoes do Seu Client", field_146294_l / 2, 20, 0xFFFFFFFF);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }
}
