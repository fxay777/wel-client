package com.seuclient.gui;

import com.seuclient.core.Config;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class TelaCores extends GuiScreen {
    @Override
    public void func_73866_w_() {
        field_146292_n.add(new GuiButton(0, field_146294_l / 2 - 100, field_146295_m / 2 - 30, 200, 20, "Texto: " + corHex(Config.corTexto)));
        field_146292_n.add(new GuiButton(1, field_146294_l / 2 - 100, field_146295_m / 2, 200, 20, "Destaque: " + corHex(Config.corDestaque)));
        field_146292_n.add(new GuiButton(2, field_146294_l / 2 - 100, field_146295_m / 2 + 30, 200, 20, "Voltar"));
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == 0) {
            Config.corTexto = Config.corTexto == 0xFFFFFFFF ? 0xFFFFFF55 : 0xFFFFFFFF;
        } else if (button.field_146127_k == 1) {
            Config.corDestaque = Config.corDestaque == 0xFF00FF00 ? 0xFF55FFFF : 0xFF00FF00;
        } else if (button.field_146127_k == 2) {
            field_146297_k.func_147108_a(new TelaConfiguracao());
            return;
        }
        func_73866_w_();
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        func_73732_a(field_146289_q, "Cores do Seu Client", field_146294_l / 2, 20, Config.corTexto);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    private String corHex(int cor) {
        return String.format("#%06X", cor & 0xFFFFFF);
    }
}
